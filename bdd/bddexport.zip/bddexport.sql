-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.1.21-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win32
-- HeidiSQL Versión:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para registre
CREATE DATABASE IF NOT EXISTS `registre` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `registre`;

-- Volcando estructura para tabla registre.admin
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nif` varchar(50) NOT NULL,
  `ultimaconex` varchar(50) NOT NULL,
  `ip` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_admin_usuari` FOREIGN KEY (`id`) REFERENCES `usuari` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla registre.admin: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;

-- Volcando estructura para tabla registre.imagenes
CREATE TABLE IF NOT EXISTS `imagenes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(200) NOT NULL DEFAULT '0',
  `url` varchar(200) NOT NULL DEFAULT '0',
  `subidopor` varchar(200) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla registre.imagenes: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `imagenes` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagenes` ENABLE KEYS */;

-- Volcando estructura para tabla registre.mapsdestina
CREATE TABLE IF NOT EXISTS `mapsdestina` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `altitud` double NOT NULL,
  `lng` double NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `imagen` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_mapsdestina_usuari` FOREIGN KEY (`id`) REFERENCES `usuari` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla registre.mapsdestina: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `mapsdestina` DISABLE KEYS */;
/*!40000 ALTER TABLE `mapsdestina` ENABLE KEYS */;

-- Volcando estructura para tabla registre.usuari
CREATE TABLE IF NOT EXISTS `usuari` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nif` varchar(200) NOT NULL,
  `nom` varchar(50) DEFAULT '-',
  `pass` varchar(50) DEFAULT '',
  `permis` varchar(50) DEFAULT '0',
  `nombre` varchar(50) DEFAULT '',
  `poblacion` varchar(50) DEFAULT '',
  `fechanacimiento` varchar(50) DEFAULT '',
  `email` varchar(50) DEFAULT '',
  `movil` varchar(50) DEFAULT '',
  `fotperfil` varchar(200) DEFAULT '',
  `idbt` varchar(50) DEFAULT '',
  `pprinci` varchar(50) DEFAULT '',
  `ilac` varchar(50) DEFAULT '',
  `pec` varchar(50) DEFAULT '',
  `altitud` double DEFAULT NULL,
  `lng` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nif` (`nif`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla registre.usuari: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `usuari` DISABLE KEYS */;
REPLACE INTO `usuari` (`id`, `nif`, `nom`, `pass`, `permis`, `nombre`, `poblacion`, `fechanacimiento`, `email`, `movil`, `fotperfil`, `idbt`, `pprinci`, `ilac`, `pec`, `altitud`, `lng`) VALUES
	(1, 'admin', 'whaat', '4321', '1', 'pepe', 'Balaguer, España', '2017-07-04', 'pepe@correu.com', '234234234234', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQC6H8LCF7_IqFUMGjxfSMkInfFtY1ug2j1Zs48UtO1ySXB3hjIiQ', 'erer', 'wewewe', '222', 'qqqqqq', 41.7877143, 0.800838800000065),
	(5, 'wopper', 'juju', '123', '0', 'Pepitodelospalotes', 'Jerez de la Frontera, España', '2017-07-03', 'je@ja.ju', '123465487', 'http://www.apicius.es/wp-content/uploads/2012/07/IMG-20120714-009211.jpg', 'wewe1qweqwe', 'ewew2qweqweqwe', '321', 'eeeewerwerwerwerwerwerwer', 36.6850064, -6.126074399999993),
	(7, 'retete', '-', 'retete', '1', 'retete', 'Valencia/España', '2017-07-19', '234234', '234234', '23423', 'retete', 'retete', '234', '234', 39.4699075, -0.3762881000000107);
/*!40000 ALTER TABLE `usuari` ENABLE KEYS */;

-- Volcando estructura para tabla registre.videos
CREATE TABLE IF NOT EXISTS `videos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(200) NOT NULL DEFAULT '0',
  `url` varchar(200) NOT NULL DEFAULT '0',
  `subidopor` varchar(200) NOT NULL DEFAULT '0',
  `fecha` varchar(200) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `Índice 2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla registre.videos: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `videos` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
